package uz.umarov.todo

object PlanObject {

    var toDoPlanList = ArrayList<MyData>()

}
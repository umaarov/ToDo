package uz.umarov.todo

data class UserData (val img:Int, val name:String)